package de.unistuttgart.dsass2022.ex00.p3;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;
import java.util.concurrent.TimeUnit;

import de.unistuttgart.dsass2022.ex00.p3.ISimpleListIterable;
import de.unistuttgart.dsass2022.ex00.p3.SimpleList;

public class SimpleListTest {

}
